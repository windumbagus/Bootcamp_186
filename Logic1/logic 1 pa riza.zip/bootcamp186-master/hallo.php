<?php
	//echo "hallo php";
	//variable
	$name = "arrizaqu";
	$age = 17;
	$email = 'arrizaqu@yahoo.com';
	
	//concat
	echo "hallo,". $name . " your age : ". $age. " email : ". $email;
	
	//debuging php var_dump
	echo "<pre>";
		var_dump($name);
		var_dump($age);
		var_dump($email);
	echo "</pre>";
	
	
	//LOOPING
	for($i = 0; $i < 5; $i++){
		echo "<br>". $i;
	}
	
	//if else
	if($name == 'arrizaqu2'){
		echo "". $name;
	} else {
		echo "yang lain";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
